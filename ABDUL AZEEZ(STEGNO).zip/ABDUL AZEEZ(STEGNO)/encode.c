#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Function Definitions */
/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */

/* Main function to perform encoding of secret file into BMP image */
Status do_encoding(EncodeInfo *encInfo)
{
    char extn_secret_file[20];// Array to store secret file extension
    int extn_size;// Variable to store extension size

    printf("Opening required files\n");

    /* Open source image, secret file and destination image */
    if(open_files(encInfo)==e_success)
    {
        printf("Files opened Successfully\n");
    }
    else
    {
        printf("Files could not opened. Please check the file path once\n");
        return e_failure;
    }

    /* Check whether image has enough capacity to store secret data */
    if(check_capacity(encInfo)==e_success)//check capacity
    {
        printf("Image have enough capacity to encode data\n");
    }
    else
    {
        printf("Inage doesn't have enough capacity to encode the data\n");
        return e_failure;
    }

    /* Copy first 54 bytes BMP header from source to destination */
    if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_dest_image)== e_success)//copy bmp header
    {
        printf("BMP header copied Successfull\n");
    }
    else
    {
        printf("Failed to BMP header\n");
        return e_failure;
    }

    /* Encode predefined magic string into image */
    if(encode_magic_string(MAGIC_STRING,encInfo)==e_success)//encode magic string
    {
        printf("Encoded magic string successfully\n");
    }
    else
    {
        printf("Encoding of magic string failed\n");
        return e_failure;
    }

    /* Extract extension from secret file name */
    strcpy(encInfo->extn_secret_file,strchr(encInfo->secret_fname,'.'));//secret file extension
    /* Calculate extension length */
    extn_size=strlen(encInfo->extn_secret_file);//find extension length

    /* Encode secret file extension size */
    if(encode_secret_file_extn_size(extn_size,encInfo)==e_success)//encode extension size
    {
        printf("Encoded secret file extn size encoded successfully\n");
    }
    else
    {
        printf("Encoding secret file extension size failed\n");
        return e_failure;
    }

    /* Encode secret file extension */
    if(encode_secret_file_extn(encInfo->extn_secret_file,encInfo)==e_success)
    {
        printf("Secret file extension encoded successfully\n");
    }
    else
    {
        printf("Encoding secret file extension failed\n");
        return e_failure;
    }

    /* Encode secret file size */
    if(encode_secret_file_size(encInfo->size_secret_file,encInfo)==e_success)
    {
        printf("Secret file size encoded successfully\n");
    }
    else
    {
        printf("Encoding secret file size failed\n");
        return e_failure;
    }

    /* Encode secret file data */
    if(encode_secret_file_data(encInfo)==e_success)//encode secret file size
    {
        printf("Encoded secret file data successfully\n");
    }
    else
    {
        printf("Encoding secret file data failed\n");
        return e_failure;
    }

    /* Copy remaining image data */
    if(copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_dest_image)==e_success)
    {
        printf("Remaining image data copied successfully\n");
    }
    else
    {
        printf("Copying remaining image data failed\n");
        return e_failure;
    }

    /* Close all opened files */
    fclose(encInfo->fptr_src_image);
    fclose(encInfo->fptr_secret);
    fclose(encInfo->fptr_dest_image);
    return e_success;
}

uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    // Find the size of secret file data
    int size;
    fseek(fptr,0,SEEK_END);//seek to end 
    size=ftell(fptr);//store fptr size
    fseek(fptr,0,SEEK_SET);//seek to set
    return size;
}

/* Function to read and validate encoding command line arguments */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    /* Validate source image file (.bmp) */
    if(strstr(argv[2],".bmp")!=NULL)
    {
        encInfo->src_image_fname=argv[2];
    }
    else
    {
        printf("ERROR: Source image file must be a .bmp file\n");
        return e_failure;
    }
    /* Validate secret file (.txt / .c / .h) */
    if(strstr(argv[3],".txt")!=NULL || strstr(argv[3],".c")!=NULL || strstr(argv[3],".h")!=NULL || strstr(argv[3],".sh")!=NULL)
    {
        encInfo->secret_fname=argv[3];
    }
    else
    {
        printf("ERROR: Secret file must be a .txt file\n");
        return e_failure;
    }
    /* Validate output image file or assign default */
    if(argv[4]!=NULL)
    {
        if(strstr(argv[4],".bmp")!=NULL)
        {
            encInfo->dest_image_fname=argv[4];
        }
        else
        {
            printf("ERROR: Output file must be a .bmp file\n");
            return e_failure;
        }
    }
    else
    {
        encInfo->dest_image_fname="dest.bmp";// Default output file
    }
    return e_success;
}

Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "rb");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // dest Image file
    encInfo->fptr_dest_image = fopen(encInfo->dest_image_fname, "wb");
    // Do Error handling
    if (encInfo->fptr_dest_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->dest_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    uint image_capacity=get_image_size_for_bmp(encInfo->fptr_src_image);//source fil pointer
    uint size_secret_file=get_file_size(encInfo->fptr_secret);//secret file pointer
    encInfo->size_secret_file=size_secret_file;
    uint magic_bits=strlen(MAGIC_STRING)*8;
    uint extn_bits=strlen(strchr(encInfo->secret_fname,'.'))*8;
    uint total_bits=magic_bits+32+extn_bits+32+(size_secret_file*8);
    //if(image_capacity>(16+32+32+32+(size_secret_file*8)))
    if(image_capacity>=total_bits)/* Check capacity */
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

/* Function to copy BMP header from source to destination image */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char imageBuffer[54];//store 54 bytes bmp header
    rewind(fptr_src_image);//rewind the source file pointer 
    if(fread(imageBuffer,1,54,fptr_src_image)!=54)//read 54 bytes from the src image
    {
        printf("ERROR: Unable to read BMP header\n");
        return e_failure;
    }
    if(fwrite(imageBuffer,1,54,fptr_dest_image)!=54)//write 54 bytes into imageBuffer
    {
        printf("ERROR: Unable to write BMP header\n");
        return e_failure;
    }
    if(ftell(fptr_src_image)==54 && ftell(fptr_dest_image)==54)//check file pointers are at same offset are not
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

/* Encode predefined magic string into image */
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char imageBuffer[8];//take one variable of size of char to store the data
    int i;
    for(int i=0;magic_string[i]!='\0';i++)// run loop till the magic string 
    {
        if(fread(imageBuffer,1,8,encInfo->fptr_src_image)!=8)//read the bits from magic string[i];
        {
            printf("ERROR: Unable to read image data\n");
            return e_failure;
        }
        encode_byte_to_lsb(magic_string[i],imageBuffer);//encode it to lsb 
        if(fwrite(imageBuffer,1,8,encInfo->fptr_dest_image)!=8)//write the data in dest image 
        {
            printf("ERROR: Unable to write image data\n");
            return e_failure;
        }
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))//check the offsets of the both the file pointers
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

/* Encode secret file extension size */
Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
    char imageBuffer[32];
    if(fread(imageBuffer,1,32,encInfo->fptr_src_image)!=32)//read 32 bytes from source image
    {
        return e_failure;
    }
    encode_size_to_lsb(size,imageBuffer);//encode size into lsb of 32 bytes

    if(fwrite(imageBuffer,1,32,encInfo->fptr_dest_image)!=32)//modified buffer into dest image
    {
        return e_failure;
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))//check off sets both file poiters
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

/* Encode secret file extension */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char imageBuffer[8];
    int i;
    for(int i=0;file_extn[i]!='\0';i++)//loop for each character of file extension
    {
        if(fread(imageBuffer,1,8,encInfo->fptr_src_image)!=8)//read 8 bytes from source image
        {
            return e_failure;
        }
        encode_byte_to_lsb(file_extn[i],imageBuffer);//encode one byte of extension into lsb
        if(fwrite(imageBuffer,1,8,encInfo->fptr_dest_image)!=8)//modified bytes in dest image
        {
            return e_failure;
        }
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))//check file offsets
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

/* Encode secret file size */
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char imageBuffer[32];
    if(fread(imageBuffer,1,32,encInfo->fptr_src_image)!=32)//read 32 bytes from source image
    {
        return e_failure;
    }
    encode_size_to_lsb(file_size,imageBuffer);//encode file size into lsb
    if(fwrite(imageBuffer,1,32,encInfo->fptr_dest_image)!=32)
    {
        return e_failure;
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))//check file offset
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

 /* Encode secret file data */
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char imageBuffer[8];
    char ch;
    rewind(encInfo->fptr_secret);//rewind secret file pointer
    
    for(long i=0;i<encInfo->size_secret_file;i++)
    {
        if(fread(&ch,1,1,encInfo->fptr_secret)!=1)
        {
            printf("ERROR : Failed to read secret file\n");
            return e_failure;
        }
        if(fread(imageBuffer,1,8,encInfo->fptr_src_image)!=8)//read 8 bytes from source image
        {
            printf("ERROR : Not enough image data to encode secret\n");
            return e_failure;
        }
        encode_byte_to_lsb(ch,imageBuffer);//encode secret byte into image lsb 
        if(fwrite(imageBuffer,1,8,encInfo->fptr_dest_image)!=8)//write modified bytes into 
        {
            printf("ERROR : Failed to write encoded data\n");
            return e_failure;
        }
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_dest_image))//check file offset
    {
        return e_success;
    }
    else
    {
        printf("ERROR: Copying secrete file data failed\n");
        return e_failure;
    }
}

/* Copy remaining image data */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char buffer[1024];
    size_t bytes;
    while((bytes=fread(buffer,1,sizeof(buffer),fptr_src))>0)
    {
        if(fwrite(buffer,1,bytes,fptr_dest)!=bytes)
        {
            return e_failure;
        }
    }
    return e_success;
}

/* Function to encode one byte of data into LSB of 8 image bytes */
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    int i;
    char bit;
    for(int i=0;i<8;i++)
    {
        bit=(data>>(7-i))&1;//get ith bit from data msb to lsb
        image_buffer[i]&=~1;//clear lsb
        image_buffer[i]|=bit;//set lsb
    }
    return e_success;
}

/* Function to encode 32-bit size into LSB of 32 image bytes */
Status encode_size_to_lsb(int size, char *imageBuffer)
{
    int i;
    int bit;
    for(int i=0;i<32;i++)//generate loop 32 times
    {
        bit=(size>>(31-i))&1; //get ith bit from size or data
        imageBuffer[i]&=~1;//clear lsb bit of imageBuffer[i]
        imageBuffer[i]|=bit;//set the get bit in the lsb of imageBuffer[i]
    }
    return e_success;
}