#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types

#define MAX_SECRET_BUF_SIZE 1000
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
    /* Source Image info */
    char *src_image_fname;
    FILE *fptr_src_image;

    /* Secret File Info */
    char secret_fname[20];
    FILE *fptr_secret;
    uint magic_size;
    uint extn_size;
    uint data_size;
    char magic_str[100]; //encode magic string
    char extn[20];
    char data[100000];
    
    char magic_string[20]; //input magic string

} DecodeInfo;
/* Decoding function prototype */

/* Read and validate decode args from argv */
Status read_and_validate_decode_args(int argc, char *argv[], DecodeInfo *decInfo);

/* Perform the encoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p  */
Status open_file(DecodeInfo *decInfo);

Status skip_header(DecodeInfo *decInfo);

Status magic_string_size(DecodeInfo *decInfo);

unsigned int decode_size_to_lsb(DecodeInfo *decInfo);

Status magic_string(DecodeInfo *decInfo);

Status magic_string_to_lsb(uint data_size ,char data[] , DecodeInfo *decInfo);

Status decode_secret_file_extn_size(DecodeInfo *decInfo);

Status decode_secret_file_extn(DecodeInfo *decInfo);

Status open_extn_file(DecodeInfo *decInfo);

Status decode_secret_data_size(DecodeInfo *decInfo);

Status decode_secret_data(DecodeInfo *decInfo);

#endif
