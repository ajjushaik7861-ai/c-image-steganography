#include<stdio.h>
int main()
{
    int 10;
}