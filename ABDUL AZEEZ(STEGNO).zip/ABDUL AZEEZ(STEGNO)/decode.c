#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"decode.h"
#include"types.h"
#include"common.h"

Status read_and_validate_decode_args(int argc, char *argv[],DecodeInfo *decInfo)
{
    /* Validate source image file (must be .bmp) */
    if(strstr(argv[2],".bmp")!=NULL)
    {
        decInfo->src_image_fname=argv[2];
    }
    else
    {
        printf("ERROR: sorce image file be a .bmp file\n");
        return e_failure;
    }

    /* Check if output file name is provided */
    if(argc >=4 && argv[3]!=NULL)
    {
        /* Validate output file extension (.txt or .c or .h allowed) */
        if(strstr(argv[3],".txt")!=NULL ||strstr(argv[3],".c")!=NULL|| strstr(argv[3],".h")!=NULL ||strstr(argv[3],".h")!=NULL)
        {
            strcpy(decInfo->secret_fname,argv[3]);
        }
        else
        {
            printf("ERROR: secret file must be .txt file\n");
            return e_failure;
        }
    }
    else
    {
        strcpy(decInfo->secret_fname,"output");//if user didnt provide default it create extension file
        printf("INFO: Output file not provided. Using default base name: output\n");
    }
    return e_success;
}

Status do_decoding(DecodeInfo *decInfo)
{
    /* Open the stego image file */
    if(open_file(decInfo)==e_success)
    {
        printf("Files opened  successfully\n");
    }
    else
    {
        printf("Opening of files failed\n");
        return e_failure;
    }

    /* Skip the 54 bytes BMP header */
    if(skip_header(decInfo)==e_success)
    {
        printf("Skipped the header successfully\n");
    }
    else
    {
        printf("Skipped of header failed\n");
        return e_failure;
    }

    /* Set magic string size (length of predefined magic string) */
    decInfo->magic_size=strlen(MAGIC_STRING);

    /* Decode magic string from the image */
    if(magic_string(decInfo)!=e_success)
    {
        printf("Decode of magic string failed\n");
        return e_failure;
    }
    printf("Decoded magic string = [%s]\n", decInfo->magic_str);

    /* Compare decoded magic string with original magic string */
    if(strcmp(decInfo->magic_str, MAGIC_STRING) == 0)
    {
        printf("Both magic string are same\n");
    }
    else
    {
        printf("Both magic string are not same\n");
        return e_failure;
    }

    /* Decode secret file extension size */
    if(decode_secret_file_extn_size(decInfo)==e_success)
    {
        printf("Decode of secret file extn size successfully\n");
    }
    else
    {
        printf("Decode of secret file extn size failed\n");
        return e_failure;
    }

    /* Decode secret file extension */
    if(decode_secret_file_extn(decInfo)==e_success)
    {
        printf("Decode of secret fie extn successfully\n");
    }
    else
    {
        printf("Decode of secret file extn failed\n");
        return e_failure;
    }
    printf("Decoded file extension = [%s]\n", decInfo->extn);

    /* If user has not given output file name,
    append decoded extension to default base name */
    if (strstr(decInfo->secret_fname, ".") == NULL)
    {
    strcat(decInfo->secret_fname, decInfo->extn);

    printf("INFO: Output file name created as: %s\n", decInfo->secret_fname);
    }

    /* Open output secret file with decoded file name */
    if(open_extn_file(decInfo)==e_success)
    {
        printf("Extn File opened successfully\n");
    }
    else
    {
        printf("Extn file not opening failed\n");
        return e_failure;
    }

    /* Decode secret data size from image */
    if(decode_secret_data_size(decInfo)==e_success)
    {
        printf("Decode of secret data size is successfully completed\n");
    }
    else
    {
        printf("Decode of secret data size is failed\n");
        return e_failure;
    }

    /* Decode secret data and write into output file */
    if(decode_secret_data(decInfo)==e_success)
    {
        printf("Decode of secret data successfully\n");
    }
    else
    {
        printf("Decode of secret data failed\n");
        return e_failure;
    }

    fclose(decInfo->fptr_src_image);
    fclose(decInfo->fptr_secret);

    /* Return success after successful decoding */
    return e_success;
}

/*Function to open the dest image file for decoding */

Status open_file(DecodeInfo *decInfo)
{
    /* Open source image file in binary read mode */
    decInfo->fptr_src_image=fopen(decInfo->src_image_fname,"rb");

    /* Check whether file opened successfully or not */
    if(decInfo->fptr_src_image==NULL)
    {
        perror("fopen");
        fprintf(stderr,"ERROR : unable to open file %s\n",decInfo->src_image_fname);
        return e_failure;
    }
    return e_success;
}

/* Function to skip BMP header (first 54 bytes) */
Status skip_header(DecodeInfo *decInfo)
{
    /* Move file pointer to 54th byte where pixel data starts */
    if(fseek(decInfo->fptr_src_image, 54, SEEK_SET)!=0)
    {
        printf("ERROR : Unable to skip BPM head\n");
        return e_failure;
    }
    return e_success;
}
/* Function to decode the size of magic string from image */
Status magic_string_size(DecodeInfo *decInfo)
{
    /* Decode 32-bit magic string size from LSB of image */
    decInfo->magic_size=decode_size_to_lsb(decInfo);
    printf("Decoded magic string size = %u\n", decInfo->magic_size);

    /* Validate decoded magic string size */
    if (decInfo->magic_size == 0 || decInfo->magic_size >= sizeof(decInfo->magic_str))
    {
        printf("ERROR: Invalid magic string size\n");
        return e_failure;
    }

    return e_success;
}

/* Function to decode a 32-bit size value from LSB of image bytes */
unsigned int decode_size_to_lsb(DecodeInfo *decInfo)
{
    unsigned int size=0; // Variable to store decoded size
    unsigned char byte; // Variable to store one image byte

    /* Loop to read 32 bits (one bit from each image byte) */
    for(int i=0;i<32;i++)
    {
        /* Read one byte from image */
        if(fread(&byte,1,1,decInfo->fptr_src_image)!=1)
        {
            return 0;
        }
        /* Shift size left and add the LSB of current byte */
        size=(size<<1)|(byte&1);
    }
    return size;
}

/* Function to decode a string from LSB of image bytes */
Status magic_string_to_lsb(uint data_size,char data[],DecodeInfo *decInfo)
{
    /* Loop for each character to be decoded */
    for(uint i=0;i<data_size;i++)
    {
        unsigned char ch=0;
        /* Decode 8 bits for one character */
        for(int j=0;j<8;j++)
        {
            unsigned char byte;
            if(fread(&byte,1,1,decInfo->fptr_src_image)!=1)/* Read one byte from image */
            return e_failure;
            ch = (ch<<1)|(byte&1);/* Shift left and add LSB bit to form character */
        }
        data[i] = ch;/* Store decoded character into data array */
    }
    data[data_size] = '\0';
    return e_success;
}

/* Function to decode the magic string from the image */
Status magic_string(DecodeInfo *decInfo)
{
    /* Call function to decode magic string using its size */
    return magic_string_to_lsb(decInfo->magic_size,decInfo->magic_str,decInfo);
}

/* Function to decode secret file extension size */
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    /* Decode extension size from image */
    decInfo->extn_size = decode_size_to_lsb(decInfo);

    /* Validate extension size */
    if (decInfo->extn_size == 0 || decInfo->extn_size >= sizeof(decInfo->extn))
    {
        printf("ERROR: Invalid extension size\n");
        return e_failure;
    }
    return e_success;
}

/* Function to decode secret file extension from image */
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    /* Decode extension string using decoded extension size */
    if(magic_string_to_lsb(decInfo->extn_size,decInfo->extn,decInfo)==e_success)
    {
        return e_success;
    }
    else
    {
        printf("ERROR: Unable to decode secret file extension\n");
        return e_failure;
    }
}

/* Function to open output secret file with decoded file name */
Status open_extn_file(DecodeInfo *decInfo)
{
    /* Open secret output file in binary write mode */
    decInfo->fptr_secret=fopen(decInfo->secret_fname,"wb");
    if(decInfo->fptr_secret==NULL)/* Check whether file opened successfully or not */
    {
        perror("fopen");
        fprintf(stderr,"ERROR : unable to open file %s\n",decInfo->secret_fname);
        return e_failure;
    }
    return e_success;
}

/* Function to decode secret data size from image */
Status decode_secret_data_size(DecodeInfo *decInfo)
{
    decInfo->data_size = decode_size_to_lsb(decInfo);/* Decode secret data size */
    /* Validate decoded data size */
    if (decInfo->data_size == 0 || decInfo->data_size >= sizeof(decInfo->data))
    {
        printf("ERROR: Invalid secret data size\n");
        return e_failure;
    }
    return e_success;
}

/* Function to decode secret file data from image */
Status decode_secret_data(DecodeInfo *decInfo)
{
    for(uint i = 0; i < decInfo->data_size; i++)
    {
        unsigned char ch = 0; // Variable to store decoded character
        unsigned char byte; // Variable to store one image byte
        /* Decode 8 bits to form one character */
        for (int j = 0; j < 8; j++)
        {
            /* Read one byte from image */
            if (fread(&byte, 1, 1, decInfo->fptr_src_image) != 1)
            {
                printf("ERROR: Unable to read image data while decoding secret data\n");
                return e_failure;
            }
            /* Shift left and add LSB bit */
            ch = (ch << 1) | (byte & 1);
        }
        /* Write decoded character into output secret file */
        fputc(ch, decInfo->fptr_secret);
    }
    return e_success;
}