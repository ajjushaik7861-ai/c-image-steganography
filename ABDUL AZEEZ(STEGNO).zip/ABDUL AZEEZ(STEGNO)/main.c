/* 
NAME        : MD ABDUL AZEEZ
DATE        : 23-01-2026
DESCRIPTION : This project implements Image Steganography using the Least Significant Bit (LSB) technique.
              Steganography is the process of hiding secret data inside an image so that the presence 
              of the data cannot be easily detected.

              In this project, a secret file (.txt / .c / .h) is hidden inside a BMP image file and 
              later retrieved back without losing the original data. The program supports both 
              encoding and decoding operations.

              The following are the main functions used in the Steganography project.

1. Encode Operation:
   Hides a secret file inside a BMP image file.
   The program reads the source image and secret file, checks if the image has enough capacity, 
   and encodes the data using LSB method.
   The output is a new stego image containing the hidden data.

2. Decode Operation:
   Extracts the hidden secret file from the stego image.
   The program reads the encoded image, verifies the magic string, retrieves the file extension, 
   file size, and finally decodes the secret data into a new output file.

3. Read and Validate Arguments:
   Validates command line arguments for encoding and decoding.
   Checks file formats such as .bmp for image files and .txt / .c / .h for secret files.

4. Open Files:
   Opens source image file, secret file, and destination image or output file.
   Performs error checking to ensure all files are opened successfully.

5. Check Capacity:
   Calculates the image capacity and verifies whether the image has enough space 
   to store the secret file data.

6. Encode Magic String:
   Encodes a predefined magic string into the image to identify whether the image 
   contains hidden data or not.

7. Encode File Extension and Size:
   Encodes the secret file extension and secret file size into the image 
   so that the decoder can correctly reconstruct the original file.

8. Encode Secret File Data:
   Encodes each byte of the secret file into the least significant bits of the image bytes.

9. Decode Magic String:
   Reads and verifies the magic string from the encoded image to confirm valid steganography data.

10. Decode File Extension and Size:
    Retrieves the hidden file extension and secret file size from the image.

11. Decode Secret File Data:
    Extracts the hidden data from the image and writes it into the output file.

12. Save and Exit:
    Saves the decoded secret data into an output file and closes all opened files safely.
    Ensures no data loss and proper termination of the program.
*/

#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include "decode.h"
OperationType check_operation_type(char *symbol[]);
int main(int argc, char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo decInfo;

    if(argc<2)//less than 2 argc not allowed 
    {
        printf("ERROR: Invalid number of arguments.\n");
        printf("For encoding required arguments :./a.out -e <sorce_file> <secret_file> [output_file]\n");
        printf("For decoding required arguments : ./a.out -d <destiation_file  output.txt\n");
        return e_failure;
    }
    int result=check_operation_type(argv);//check operation type(-e or -d)

    if(result == e_encode)//check operation -e are there not in arguments
    {
        if(argc<4)//less than 4 not allowed
        {
            printf("ERROR : Invalid number of arguments\n");
            printf("For encoding required arguments : ./a.out -e sorce file  secret.txt destination file\n");
            return e_failure;
        }
        printf("Encoded mode selected\n");
        if(read_and_validate_encode_args(argv,&encInfo)==e_success)//validate the argc
        {
            printf("Read and validation Successfully completed!!\n");
            if(do_encoding(&encInfo)==e_success)//for encoding the argc
            {
                printf("File Encoded successfully\n");
            }
            else
            {
                printf("ERROR : Encoding file not Successfull\n");
                return e_failure;
            }
        }
        else
        {
            printf("Validation failed\n");
            return e_failure;
        }
    }
    else if(result==e_decode)//if it is -d
    {
        if(argc<3)//less than 3 not allowed
        {
            printf("ERROR: Invalid number of arguments for decoding.\n");
            printf("For decoding required arguments : ./a.out -d <destiation_file  output.txt\n");
            return e_failure;
        }
        printf("Decoded mode selected\n");
        if(read_and_validate_decode_args(argc,argv,&decInfo)==e_success)//function for validation arguments
        {
            printf("Read and validation Successfully\n");
            if(do_decoding(&decInfo)==e_success)//decoding for argc
            {
                printf("File Decoded Successfully\n");
            }
            else
            {
                printf("ERROR : Decoding file failed\n");
                return e_failure;
            }
        }
        else
        {
            printf("ERROR: Validation failed\n");
            return e_failure;
        }
    }
    else
    {
        printf("ERROR: Invalid operation type. Use -e or -d\n");
        return e_failure;
    }
    return e_success;
}

OperationType check_operation_type(char *symbol[])
{
    if(strcmp(symbol[1],"-e")==0)//compares the arggument equal or not
    {
        return e_encode;
    }
    else if(strcmp(symbol[1],"-d")==0)//compares the arguments equal or not
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}
